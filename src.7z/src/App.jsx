import Parent from "./components/Parent";

import "./App.css";

function App() {
  return (
    <>
      <Parent />
    </>
  );
}

export default App;
