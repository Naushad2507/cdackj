import React from "react";

function Child({ setColor, age }) {
  const changeColor = (e) => {
    setColor(e.target.value);
  };

  return (
    <div className="child">
      <h1>Child {age}</h1>
      <input type="text" onChange={changeColor} />
    </div>
  );
}

export default Child;
