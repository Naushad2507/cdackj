import React, { useState } from "react";
import Child from "./Child";

function Parent() {
  const [UIColor, setUIColor] = useState(null);

  const getColor = (color) => {
    setUIColor(color);
  };

  return (
    <div className="parent">
      <h1 style={{ backgroundColor: `${UIColor}` }}>Parent</h1>
      <Child setColor={getColor} age="100" />
    </div>
  );
}

export default Parent;
