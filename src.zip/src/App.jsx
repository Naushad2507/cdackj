import { useEffect, useState } from "react";
import reactLogo from "./assets/react.svg";
import viteLogo from "/vite.svg";
import "./App.css";
import Employee from "./components/employee";
import AddEmployee from "./components/AddEmployee";

function App() {
  const [employees, setEmployees] = useState([]);

  const fetchEmployees = () => {
    // employees[0] = { id: 1, name: "naushad", role: "manager" };
    // employees[1] = { id: 11, name: "naushad", role: "manager" };
    // employees[2] = { id: 22, name: "naushad", role: "manager" };

    const url = "http://localhost:8080/employees";
    fetch(url)
      .then((response) => response.json())
      .then((employees) => setEmployees(employees));
  };

  useEffect(() => {
    fetchEmployees();
  }, []);

  const addEmployee = (name, role) => {
    console.log(name + " " + role);
    const url = "http://localhost:8080/employee";
    fetch(url, {
      method: "POST",
      body: JSON.stringify({
        id: Number(Math.random().toString(36).slice(2)),
        name: name,
        role: role,
      }),
      headers: {
        "Content-type": "application/json;charset=UTF-8",
      },
    })
      .then((response) => response.json())
      .then((emp) => {
        setEmployees((em) => [emp, ...em]);
      });
  };

  const deleteEmployee = (id) => {
    console.log("employee deleted " + id);
    const url = `http://localhost:8080/employee/${id}`;
    fetch(url, {
      method: "DELETE",
    }).then((response) => {
      if (response.status == 200) {
        setEmployees(
          employees.filter((emp) => {
            return emp.id !== id;
          })
        );
      }
    });
  };

  return (
    <>
      <h1>Employee Management - Naushad</h1>
      <AddEmployee addEmployee={addEmployee} />
      <section
        className="posts-container"
        style={{
          borderStyle: "groove",
          borderColor: "red",
        }}
      >
        {employees.map((employee) => (
          <Employee
            key={employee.id}
            id={employee.id}
            name={employee.name}
            role={employee.role}
            deleteEmployee={deleteEmployee}
          />
        ))}
      </section>
    </>
  );
}

export default App;
