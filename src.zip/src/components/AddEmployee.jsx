import React, { useState } from "react";

function AddEmployee(props) {
  const [name, setName] = useState("");
  const [role, setRole] = useState("");

  // const uname = (uname) => {
  //   setName(uname.target.value);
  // };

  const handleSubmit = (e) => {
    e.preventDefault();
    props.addEmployee(name, role);
    setName("");
    setRole("");
  };

  return (
    <div>
      <h1>AddEmployee</h1>
      <form onSubmit={handleSubmit}>
        <div className="input-container">
          <label>Name: </label>
          <input
            type="text"
            name="uname"
            value={name}
            onChange={(uname) => {
              setName(uname.target.value);
            }}
          />
        </div>
        <div className="input-container">
          <label>Role: </label>
          <input
            type="text"
            name="role"
            value={role}
            onChange={(role) => {
              setRole(role.target.value);
            }}
          />
        </div>
        <button type="submit" className="btn-submit">
          Add Employee
        </button>
      </form>
    </div>
  );
}

export default AddEmployee;
