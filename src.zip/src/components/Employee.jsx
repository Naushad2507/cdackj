import React from "react";
import "../App.css";

function Employee(props) {
  return (
    <div className="post-card">
      <h2 className="post-title">{props.name}</h2>
      <h3 className="post-title">{props.id}</h3>
      <h3 className="post-title">{props.role}</h3>
      <br /> <br />
      <button
        className="btn-delete"
        onClick={() => props.deleteEmployee(props.id)}
      >
        Delete
      </button>
    </div>
  );
}

export default Employee;
